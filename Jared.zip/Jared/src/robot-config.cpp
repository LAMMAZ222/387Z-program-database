#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor Ldrive = motor(PORT15, ratio18_1, false);
motor Rdrive = motor(PORT16, ratio18_1, true);
controller Controller1 = controller(primary);
motor Lintake = motor(PORT14, ratio18_1, false);
motor Rintake = motor(PORT4, ratio18_1, true);
motor Llift = motor(PORT17, ratio18_1, false);
motor Rlift = motor(PORT7, ratio18_1, true);
motor Ltower = motor(PORT18, ratio18_1, false);
motor Rtower = motor(PORT8, ratio18_1, true);

// VEXcode generated functions



/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Text.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}