using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor Ldrive;
extern motor Rdrive;
extern controller Controller1;
extern motor Lintake;
extern motor Rintake;
extern motor Llift;
extern motor Rlift;
extern motor Ltower;
extern motor Rtower;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Text.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );